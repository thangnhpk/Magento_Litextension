<?php

namespace LitExtension\Core\Logger;

class Logger extends \Monolog\Logger
{
    
}
