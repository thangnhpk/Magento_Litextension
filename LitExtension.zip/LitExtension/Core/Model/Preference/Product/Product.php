<?php

namespace LitExtension\Core\Model\Preference\Product;

class Product extends \Magento\Catalog\Model\Product
{
    public function addImageToMediaGallery($file, $mediaAttribute = null, $move = false, $exclude = true, $label = '')
    {
        $attributes = $this->getTypeInstance()->getSetAttributes($this);
        if (!isset($attributes['media_gallery'])) {
            return $this;
        }
        $mediaGalleryAttribute = $attributes['media_gallery'];
        /* @var $mediaGalleryAttribute \Magento\Catalog\Model\ResourceModel\Eav\Attribute */
        $mediaGalleryAttribute->getBackend()->addImage($this, $file, $mediaAttribute, $move, $exclude, $label);
        return $this;
    }
}

