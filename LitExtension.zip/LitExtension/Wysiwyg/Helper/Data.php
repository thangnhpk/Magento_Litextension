<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace LitExtension\Wysiwyg\Helper;

use Magento\Framework\App\Action\Action;

/**
 * CMS Page Helper
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 * @SuppressWarnings(PHPMD.CyclomaticComplexity)
 * @SuppressWarnings(PHPMD.NPathComplexity)
 */
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    public $_storeManager;
    public $_directory_list;

    public function __construct(
    	\Magento\Store\Model\StoreManagerInterface $storeManager,
    	\Magento\Framework\App\Filesystem\DirectoryList $directory_list
	)
    {
        $this->_storeManager = $storeManager;
        $this->_directory_list = $directory_list;
    }

	public function setBaseUrl(){

		return $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA).'wysiwyg';
		// return "baseUrl";
	}

	public function setUploadDir(){
       return $this->_directory_list->getPath('media').'/wysiwyg/';
    }

    public function setSrcUploadDir(){
        $src_upload_dir = '/'; // path from base_url to base of upload folder (with start and final /)
        return $src_upload_dir;
    }

    public function setThumbsBasePath(){
        return $$this->_directory_list->getPath('media').'/thumbs/';
    }

    public function setThumbsBaseUrl(){
        return $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA).'thumbs/';
    }

    public function setSourceBaseUrl(){
        return $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA).'wysiwyg/';
    }

}
?>
