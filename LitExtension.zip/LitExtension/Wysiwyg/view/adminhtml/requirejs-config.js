/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

var config = {
    map: {
        '*': {
            tinymce4:   'tinymce_mce4/tinymce.min',
        }
    }
};