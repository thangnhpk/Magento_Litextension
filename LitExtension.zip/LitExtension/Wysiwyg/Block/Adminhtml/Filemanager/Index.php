<?php

namespace Litextension\Wysiwyg\Block\Adminhtml\Filemanager;

class Index extends \Magento\Backend\Block\Template
{

    public function __construct(
        \Magento\Backend\Block\Widget\Context $context,
        array $data = []
    ) {
        parent::__construct($context, $data);
    }

    /**
     * @return void
     */
    protected function _construct()
    {
    }
}
