<?php

namespace Litextension\Wysiwyg\Block\Adminhtml;

class Js extends \Magento\Backend\Block\Template
{
    protected $_scopeConfig;
    public $_storeManager;
    protected $_helper;
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \LitExtension\Wysiwyg\Helper\Data $helper,
        array $data = []
    ) {
        $this->_scopeConfig = $scopeConfig;
        $this->_storeManager = $storeManager;
        $this->_helper = $helper;
        parent::__construct($context, $data);
    }
    protected function _construct()
    {
        parent::_construct();
        // die($this->_helper->setUploadDir());
        // die($this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA).'wysiwyg');
        $this->setTemplate('Litextension_Wysiwyg::js.phtml');
    }
    public function getStoreConfig($path){
        return $this->_scopeConfig->getValue($path, \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

}
