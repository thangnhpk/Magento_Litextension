<?php

namespace LitExtension\Wysiwyg\Controller\Adminhtml;
/**
 * Class Vendor
 * @package Nguyenthang\Tutorial\Controller\Adminhtml
 */
abstract class Filemanager extends \Magento\Backend\App\Action
{
    /**
     * @param \Magento\Backend\App\Action\Context $context
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context
    ) {
        parent::__construct($context);
    }


    /**
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('LitExtension::filemanager');
    }
}