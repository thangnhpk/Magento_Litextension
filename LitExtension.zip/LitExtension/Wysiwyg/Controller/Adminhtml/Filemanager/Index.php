<?php

namespace LitExtension\Wysiwyg\Controller\Adminhtml\Filemanager;
use Magento\Backend\App\Action\Context;
class Index extends \Magento\Backend\App\Action
{

	/**
     * @var PageFactory
     */
    protected $resultPageFactory;

    /**
     * @param Context $context
     * @param PageFactory $resultPageFactory
     */
    public function __construct(Context $context){
        parent::__construct($context);
    }
    public function execute()
    {   
       $this->_view->loadLayout();
        $this->_view->renderLayout();
    }

}
